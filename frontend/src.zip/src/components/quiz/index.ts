export { QuizCard } from "./QuizCard";
export { ScoreCard } from "./ScoreCard";
